package com.nyxvault.lastcampfire;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Чистая сетевая логика LAN-игры (без зависимостей от Android): TCP-сервер/клиент построчным протоколом
 * и UDP-обнаружение комнат. Всё общение с JS идёт через Listener.
 *
 * События Listener.onEvent(ev, id, a):
 *   "client+"  id, a=ip       — к хосту подключился игрок
 *   "client-"  id             — игрок отключился (хост)
 *   "msg"      id, a=строка   — пришло сообщение (на хосте id клиента, на клиенте id=0)
 *   "closed"   a=причина      — клиентское соединение закрыто
 */
public class LanCore {
    public interface Listener { void onEvent(String ev, int id, String a); }
    public interface Binder {
        void bindTcp(Socket s) throws IOException;      // привязка сокета к Wi-Fi сети (Android)
        void bindUdp(DatagramSocket d) throws IOException;
    }

    public static final int MAX_LINE = 8 * 1024 * 1024;
    private static final String PROBE = "LCHOST?1";
    private static final String REPLY = "LCHOST!1";

    private final Listener listener;
    private volatile Binder binder = new Binder() {
        public void bindTcp(Socket s) { }
        public void bindUdp(DatagramSocket d) { }
    };

    // ---- сервер ----
    private ServerSocket server;
    private Thread acceptThread;
    private final Map<Integer, Conn> conns = new ConcurrentHashMap<Integer, Conn>();
    private int nextId = 1;
    private DatagramSocket respSock;
    private Thread respThread;
    private volatile String roomName = "Комната";
    private volatile int discoveryPort = 47771;
    private volatile int tcpPort;

    // ---- клиент ----
    private Conn clientConn;

    public LanCore(Listener l) { this.listener = l; }
    public void setBinder(Binder b) { this.binder = b; }
    public void setRoomName(String n) { if (n != null && n.length() > 0) this.roomName = n.replace('|', ' '); }

    // ======================= сервер =======================
    /** Запускает сервер один раз. Повторный вызов возвращает уже занятый порт (никакого EADDRINUSE). */
    public synchronized int startServer(int port, int discPort) throws IOException {
        if (server != null && !server.isClosed()) return tcpPort;
        discoveryPort = discPort;
        ServerSocket ss = new ServerSocket();
        ss.setReuseAddress(true);
        try {
            ss.bind(new InetSocketAddress(port));
        } catch (IOException e) {
            try { ss.close(); } catch (IOException ignore) { }
            // порт занят старой копией — пробуем взять любой свободный, чтобы комната всё равно открылась
            ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(0));
        }
        server = ss; tcpPort = ss.getLocalPort();
        final ServerSocket mine = ss;
        acceptThread = new Thread(new Runnable() { public void run() { acceptLoop(mine); } }, "lc-accept");
        acceptThread.setDaemon(true); acceptThread.start();
        startResponder();
        return tcpPort;
    }

    private void acceptLoop(ServerSocket ss) {
        while (!ss.isClosed()) {
            try {
                Socket s = ss.accept();
                s.setTcpNoDelay(true); s.setKeepAlive(true);
                int id; synchronized (this) { id = nextId++; }
                Conn c = new Conn(id, s, true);
                conns.put(id, c);
                String ip = s.getInetAddress() != null ? s.getInetAddress().getHostAddress() : "?";
                listener.onEvent("client+", id, ip);
                c.start();
            } catch (IOException e) {
                if (ss.isClosed()) break;
            }
        }
    }

    public synchronized void stopServer() {
        ServerSocket ss = server; server = null;
        if (ss != null) { try { ss.close(); } catch (IOException ignore) { } }
        for (Conn c : conns.values()) c.close("room closed");
        conns.clear();
        DatagramSocket d = respSock; respSock = null;
        if (d != null) d.close();
        tcpPort = 0;
    }

    public boolean isServerRunning() { ServerSocket s = server; return s != null && !s.isClosed(); }
    public int getPort() { return tcpPort; }
    public int clientCount() { return conns.size(); }

    public void sendTo(int id, String line, boolean lossy) { Conn c = conns.get(id); if (c != null) c.send(line, lossy); }
    public void broadcast(String line, boolean lossy) { for (Conn c : conns.values()) c.send(line, lossy); }
    public void kick(int id) { Conn c = conns.get(id); if (c != null) c.close("kicked"); }

    private void startResponder() throws IOException {
        DatagramSocket d = new DatagramSocket(null);
        d.setReuseAddress(true);
        d.setBroadcast(true);
        try { d.bind(new InetSocketAddress(discoveryPort)); }
        catch (IOException e) { d.close(); return; } // обнаружение — приятный бонус, не критично
        respSock = d;
        final DatagramSocket mine = d;
        respThread = new Thread(new Runnable() { public void run() {
            byte[] buf = new byte[256];
            while (!mine.isClosed()) {
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    mine.receive(p);
                    String m = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                    if (PROBE.equals(m)) {
                        byte[] r = (REPLY + "|" + roomName + "|" + tcpPort + "|" + (conns.size() + 1)).getBytes(StandardCharsets.UTF_8);
                        mine.send(new DatagramPacket(r, r.length, p.getAddress(), p.getPort()));
                    }
                } catch (IOException e) { if (mine.isClosed()) break; }
            }
        } }, "lc-disc");
        respThread.setDaemon(true); respThread.start();
    }

    // ======================= клиент =======================
    /** Блокирующее подключение. Бросает IOException с понятным текстом/кодом. */
    public synchronized void connect(String host, int port, int timeoutMs) throws IOException {
        disconnect();
        Socket s = new Socket();
        try {
            binder.bindTcp(s);                       // ключевое: трафик строго через Wi-Fi, а не мобильную сеть
            s.setTcpNoDelay(true); s.setKeepAlive(true);
            s.connect(new InetSocketAddress(host, port), timeoutMs);
        } catch (IOException e) {
            try { s.close(); } catch (IOException ignore) { }
            throw e;
        }
        Conn c = new Conn(0, s, false);
        clientConn = c;
        c.start();
    }

    public void clientSend(String line, boolean lossy) { Conn c = clientConn; if (c != null) c.send(line, lossy); }
    public boolean isConnected() { Conn c = clientConn; return c != null && !c.closed; }

    public synchronized void disconnect() {
        Conn c = clientConn; clientConn = null;
        if (c != null) { c.silent = true; c.close("disconnect"); }
    }

    // ======================= обнаружение =======================
    /** Рассылает запрос и собирает ответы. Возвращает массивы {ip, port, name, players}. */
    public List<String[]> discover(int timeoutMs, int discPort, List<String> targets) throws IOException {
        List<String[]> out = new ArrayList<String[]>();
        DatagramSocket d = new DatagramSocket(null);
        try {
            d.setReuseAddress(true); d.setBroadcast(true);
            d.bind(new InetSocketAddress(0));
            binder.bindUdp(d);
            byte[] q = PROBE.getBytes(StandardCharsets.UTF_8);
            for (String t : targets) {
                try { d.send(new DatagramPacket(q, q.length, InetAddress.getByName(t), discPort)); } catch (IOException ignore) { }
            }
            long end = System.currentTimeMillis() + timeoutMs; long lastResend = System.currentTimeMillis();
            byte[] buf = new byte[512];
            while (true) {
                long left = end - System.currentTimeMillis(); if (left <= 0) break;
                if (System.currentTimeMillis() - lastResend > 700) { // повторяем запрос: UDP может потеряться
                    lastResend = System.currentTimeMillis();
                    for (String t : targets) { try { d.send(new DatagramPacket(q, q.length, InetAddress.getByName(t), discPort)); } catch (IOException ignore) { } }
                }
                d.setSoTimeout((int) Math.min(left, 350));
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    d.receive(p);
                    String m = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                    if (!m.startsWith(REPLY + "|")) continue;
                    String[] parts = m.split("\\|");
                    if (parts.length < 4) continue;
                    String ip = p.getAddress().getHostAddress(); boolean dup = false;
                    for (String[] o : out) if (o[0].equals(ip) && o[1].equals(parts[2])) dup = true;
                    if (!dup) out.add(new String[]{ ip, parts[2], parts[1], parts[3] });
                } catch (java.net.SocketTimeoutException ignore) { }
            }
        } finally { d.close(); }
        return out;
    }

    // ======================= соединение =======================
    private class Conn {
        final int id; final Socket s; final boolean server;
        final LinkedBlockingQueue<String> q = new LinkedBlockingQueue<String>();
        volatile boolean closed; volatile boolean silent; Thread rt, wt;
        Conn(int id, Socket s, boolean server) { this.id = id; this.s = s; this.server = server; }

        void start() {
            rt = new Thread(new Runnable() { public void run() { readLoop(); } }, "lc-read-" + id);
            wt = new Thread(new Runnable() { public void run() { writeLoop(); } }, "lc-write-" + id);
            rt.setDaemon(true); wt.setDaemon(true); rt.start(); wt.start();
        }

        void send(String line, boolean lossy) {
            if (closed) return;
            if (lossy && q.size() > 12) return;      // медленный канал: устаревшие снимки мира выбрасываем
            if (q.size() > 3000) { close("send queue overflow"); return; }
            q.offer(line);
        }

        void writeLoop() {
            try {
                OutputStream os = s.getOutputStream();
                while (!closed) {
                    String line = q.poll(200, TimeUnit.MILLISECONDS);
                    if (line == null) continue;
                    byte[] b = line.getBytes(StandardCharsets.UTF_8);
                    os.write(b); os.write('\n');
                    if (q.isEmpty()) os.flush();
                }
            } catch (Exception e) { close(e.getMessage() == null ? "write error" : e.getMessage()); }
        }

        void readLoop() {
            String reason = "closed by peer";
            try {
                InputStream is = new BufferedInputStream(s.getInputStream(), 16384);
                ByteArrayOutputStream bos = new ByteArrayOutputStream(4096);
                int ch;
                while (!closed && (ch = is.read()) != -1) {
                    if (ch == '\n') {
                        String line = new String(bos.toByteArray(), StandardCharsets.UTF_8); bos.reset();
                        if (line.length() > 0) listener.onEvent("msg", id, line);
                    } else {
                        bos.write(ch);
                        if (bos.size() > MAX_LINE) { reason = "line too long"; break; }
                    }
                }
            } catch (SocketException e) { reason = e.getMessage() == null ? "socket error" : e.getMessage(); }
            catch (IOException e) { reason = e.getMessage() == null ? "io error" : e.getMessage(); }
            close(reason);
        }

        synchronized void close(String reason) {
            if (closed) return; closed = true;
            try { s.close(); } catch (IOException ignore) { }
            if (server) { conns.remove(id); if (!silent) listener.onEvent("client-", id, reason); }
            else { if (clientConn == this) clientConn = null; if (!silent) listener.onEvent("closed", 0, reason); }
        }
    }
}
