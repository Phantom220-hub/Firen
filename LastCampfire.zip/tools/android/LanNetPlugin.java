package com.nyxvault.lastcampfire;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.DhcpInfo;
import android.net.wifi.WifiManager;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Мост между JS-игрой и LanCore. Главное, что решает этот класс на Android:
 *  - находит реальные адреса телефона в Wi-Fi/точке доступа (не зашитый 192.168.43.1);
 *  - привязывает исходящие сокеты именно к Wi-Fi сети (Network.bindSocket), чтобы Android не отправлял
 *    пакеты через мобильный интернет (причина ENETUNREACH);
 *  - держит Wi-Fi и multicast блокировки, пока идёт комната.
 */
@CapacitorPlugin(name = "LanNet")
public class LanNetPlugin extends Plugin {
    private LanCore core;
    private WifiManager.WifiLock wifiLock;
    private WifiManager.MulticastLock mcLock;
    private Network boundProcessNet;
    private int discPort = 47771;

    @Override
    public void load() {
        core = new LanCore(new LanCore.Listener() {
            public void onEvent(String ev, int id, String a) {
                JSObject o = new JSObject();
                o.put("e", ev); o.put("id", id);
                if (a != null) o.put("a", a);
                notifyListeners("net", o);
            }
        });
        core.setBinder(new LanCore.Binder() {
            public void bindTcp(Socket s) throws IOException {
                Network n = findLanNetwork();
                if (n != null) n.bindSocket(s);
            }
            public void bindUdp(DatagramSocket d) throws IOException {
                Network n = findLanNetwork();
                if (n != null) n.bindSocket(d);
            }
        });
    }

    // ---------- сеть ----------
    private ConnectivityManager cm() { return (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE); }

    /** Сеть Wi-Fi (или Ethernet) — именно по ней идёт игра. */
    private Network findLanNetwork() {
        try {
            ConnectivityManager c = cm();
            Network best = null;
            for (Network n : c.getAllNetworks()) {
                NetworkCapabilities nc = c.getNetworkCapabilities(n);
                if (nc == null) continue;
                if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                    best = n;
                    if (nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) break;
                }
            }
            return best;
        } catch (Exception e) { return null; }
    }

    private static boolean skipIface(String name) {
        return name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("tun") || name.startsWith("dummy")
            || name.startsWith("p2p") || name.startsWith("lo") || name.startsWith("v4-") || name.startsWith("clat");
    }

    private static String intToIp(int v) { return (v & 0xff) + "." + ((v >> 8) & 0xff) + "." + ((v >> 16) & 0xff) + "." + ((v >> 24) & 0xff); }

    private List<String> broadcastTargets(JSArray ipsOut) {
        List<String> t = new ArrayList<String>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback() || skipIface(ni.getName())) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress a = ia.getAddress();
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress()) continue;
                    if (ipsOut != null) {
                        JSObject o = new JSObject();
                        o.put("name", ni.getName()); o.put("ip", a.getHostAddress()); o.put("prefix", (int) ia.getNetworkPrefixLength());
                        ipsOut.put(o);
                    }
                    InetAddress b = ia.getBroadcast();
                    if (b != null && !t.contains(b.getHostAddress())) t.add(b.getHostAddress());
                }
            }
        } catch (Exception ignore) { }
        try {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            DhcpInfo di = wm.getDhcpInfo();
            if (di != null && di.gateway != 0) { String g = intToIp(di.gateway); if (!t.contains(g)) t.add(g); }
        } catch (Exception ignore) { }
        if (!t.contains("255.255.255.255")) t.add("255.255.255.255");
        return t;
    }

    @PluginMethod
    public void getNetInfo(PluginCall call) {
        JSArray ips = new JSArray();
        List<String> targets = broadcastTargets(ips);
        JSObject r = new JSObject();
        r.put("ips", ips);
        r.put("wifi", findLanNetwork() != null);
        String gw = "";
        try {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            DhcpInfo di = wm.getDhcpInfo(); if (di != null && di.gateway != 0) gw = intToIp(di.gateway);
        } catch (Exception ignore) { }
        r.put("gateway", gw);
        r.put("targets", new JSArray(targets));
        call.resolve(r);
    }

    private void acquireLocks() {
        try {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifiLock == null) { wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lastcampfire-lan"); wifiLock.setReferenceCounted(false); }
            if (!wifiLock.isHeld()) wifiLock.acquire();
            if (mcLock == null) { mcLock = wm.createMulticastLock("lastcampfire-mc"); mcLock.setReferenceCounted(false); }
            if (!mcLock.isHeld()) mcLock.acquire();
        } catch (Exception ignore) { }
    }

    private void releaseLocks() {
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignore) { }
        try { if (mcLock != null && mcLock.isHeld()) mcLock.release(); } catch (Exception ignore) { }
    }

    // ---------- хост ----------
    @PluginMethod
    public void startServer(final PluginCall call) {
        final int port = call.getInt("port", 47770);
        discPort = call.getInt("discPort", 47771);
        final String name = call.getString("name", "Комната");
        new Thread(new Runnable() { public void run() {
            try {
                boolean already = core.isServerRunning();
                core.setRoomName(name);
                int p = core.startServer(port, discPort);
                acquireLocks();
                JSObject r = new JSObject();
                r.put("port", p); r.put("already", already);
                JSArray ips = new JSArray(); broadcastTargets(ips); r.put("ips", ips);
                call.resolve(r);
            } catch (Exception e) { call.reject(e.getMessage() == null ? "Не удалось запустить сервер" : e.getMessage(), "SERVER"); }
        } }, "lc-start").start();
    }

    @PluginMethod
    public void stopServer(PluginCall call) {
        core.stopServer();
        releaseLocks();
        call.resolve();
    }

    @PluginMethod
    public void kick(PluginCall call) { core.kick(call.getInt("id", -1)); call.resolve(); }

    // ---------- клиент ----------
    @PluginMethod
    public void connect(final PluginCall call) {
        final String host = call.getString("host", "");
        final int port = call.getInt("port", 47770);
        final int timeout = call.getInt("timeoutMs", 5000);
        new Thread(new Runnable() { public void run() {
            try {
                acquireLocks();
                try {   // дополнительно: весь процесс — через Wi-Fi, пока идёт игра по сети
                    Network n = findLanNetwork();
                    if (n != null) { cm().bindProcessToNetwork(n); boundProcessNet = n; }
                } catch (Exception ignore) { }
                core.connect(host, port, timeout);
                call.resolve();
            } catch (Exception e) {
                String m = String.valueOf(e.getMessage());
                String code = m.contains("ENETUNREACH") ? "ENETUNREACH" : m.contains("ECONNREFUSED") ? "ECONNREFUSED" : (e instanceof java.net.SocketTimeoutException || m.contains("timed out")) ? "TIMEOUT" : "ERR";
                call.reject(m, code);
            }
        } }, "lc-connect").start();
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        core.disconnect();
        unbindProcess();
        if (!core.isServerRunning()) releaseLocks();
        call.resolve();
    }

    private void unbindProcess() {
        try { if (boundProcessNet != null) { cm().bindProcessToNetwork(null); boundProcessNet = null; } } catch (Exception ignore) { }
    }

    // ---------- обмен ----------
    @PluginMethod
    public void send(PluginCall call) {
        int id = call.getInt("id", -1);
        String line = call.getString("line", "");
        boolean lossy = Boolean.TRUE.equals(call.getBoolean("lossy", false));
        if (core.isServerRunning() && id >= 0) core.sendTo(id, line, lossy);
        else if (core.isServerRunning()) core.broadcast(line, lossy);
        else core.clientSend(line, lossy);
        call.resolve();
    }

    @PluginMethod
    public void discover(final PluginCall call) {
        final int timeout = call.getInt("timeoutMs", 2500);
        new Thread(new Runnable() { public void run() {
            try {
                List<String> targets = broadcastTargets(null);
                List<String[]> found = core.discover(timeout, discPort, targets);
                JSArray rooms = new JSArray();
                for (String[] f : found) {
                    JSObject o = new JSObject();
                    o.put("ip", f[0]); o.put("port", Integer.parseInt(f[1])); o.put("name", f[2]); o.put("players", Integer.parseInt(f[3]));
                    rooms.put(o);
                }
                JSObject r = new JSObject(); r.put("rooms", rooms); call.resolve(r);
            } catch (Exception e) { call.reject(String.valueOf(e.getMessage()), "DISCOVER"); }
        } }, "lc-discover").start();
    }

    @Override
    protected void handleOnDestroy() {
        try { core.stopServer(); core.disconnect(); } catch (Exception ignore) { }
        unbindProcess(); releaseLocks();
    }
}
