'use strict';
/* Nyxvault — «Последний костёр». Пиксель-арт, нарисованный кодом (без картинок). */
const SPR = (function () {
  function mk(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function mulberry(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

  function grid(rows, pal, scale) {
    scale = scale || 1;
    const h = rows.length, w = rows[0].length, c = mk(w * scale, h * scale), x = c.getContext('2d');
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const ch = rows[j][i]; if (ch === '.' || ch === ' ') continue;
      const col = pal[ch]; if (!col) continue;
      x.fillStyle = col; x.fillRect(i * scale, j * scale, scale, scale);
    }
    return c;
  }

  // добавляет тёмный контур в 1 пиксель и делает белую «вспышку» для попаданий
  function finish(c, outline) {
    outline = outline || '#0e1120';
    const w = c.width, h = c.height, o = mk(w + 2, h + 2), x = o.getContext('2d');
    const sil = mk(w, h), sx = sil.getContext('2d');
    sx.drawImage(c, 0, 0); sx.globalCompositeOperation = 'source-in'; sx.fillStyle = outline; sx.fillRect(0, 0, w, h);
    [[0, 1], [2, 1], [1, 0], [1, 2]].forEach(d => x.drawImage(sil, d[0], d[1]));
    x.drawImage(c, 1, 1);
    const wc = mk(w + 2, h + 2), wx = wc.getContext('2d');
    wx.drawImage(o, 0, 0); wx.globalCompositeOperation = 'source-in'; wx.fillStyle = '#fff'; wx.fillRect(0, 0, w + 2, h + 2);
    return { c: o, wc: wc, w: w + 2, h: h + 2 };
  }

  // ---------- герои (спереди) ----------
  const HERO_A = [
    '....hhhh....',
    '...hHHHHh...',
    '..hHHHHHHh..',
    '..hHssssHh..',
    '..hsessesh..',
    '...ssssss...',
    '..cccccccc..',
    '.scccbbcccs.',
    '.sccccccccs.',
    '..ccbbbbcc..',
    '..cccccccc..',
    '...pppppp...',
    '...pp..pp...',
    '...pp..pp...',
    '..kkk..kkk..',
    '..kkk..kkk..'];
  const HERO_B = HERO_A.slice(0, 12).concat([
    '....pppp....',
    '....pppp....',
    '...kkkkkk...',
    '...kkkkkk...']);
  const HERO_PAL = {
    hunter: { h: '#2b5e3a', H: '#4c9b57', s: '#f1c08a', e: '#1a1a2e', c: '#8a5a32', b: '#e0b45e', p: '#3b3350', k: '#241a14' },
    mage: { h: '#5b2d8a', H: '#8a52c8', s: '#f1c08a', e: '#1a1a2e', c: '#3a4fa8', b: '#ffd166', p: '#2a2a55', k: '#1a1a33' },
    robot: { h: '#6b7a8f', H: '#a3b3c8', s: '#8fa0b5', e: '#37f3ff', c: '#4b5668', b: '#ff9d3a', p: '#39424f', k: '#20242c' },
    knight: { h: '#8a93a8', H: '#cfd6e6', s: '#f1c08a', e: '#1a1a2e', c: '#b8c1d6', b: '#e0394a', p: '#5a6074', k: '#2a2e3c' },
    engineer: { h: '#d9a21a', H: '#ffd447', s: '#f1c08a', e: '#1a1a2e', c: '#2f6fb8', b: '#ff9d3a', p: '#3a3f55', k: '#2a1f14' },
    rogue: { h: '#2a2236', H: '#4a3a66', s: '#e8b88a', e: '#9fff8a', c: '#3b2f55', b: '#9a7bff', p: '#241c33', k: '#14101c' },
    necro: { h: '#1f3a2a', H: '#2f6a46', s: '#cfd9c0', e: '#7dff8f', c: '#2a4a3a', b: '#7dff8f', p: '#1c2e25', k: '#101a15' }
  };

  const out = { hero: {} };
  Object.keys(HERO_PAL).forEach(k => {
    out.hero[k] = [finish(grid(HERO_A, HERO_PAL[k])), finish(grid(HERO_B, HERO_PAL[k]))];
  });

  // ---------- враги ----------
  out.slime = [finish(grid([
    '....gggg....',
    '..ggGGGGgg..',
    '.ggGGGGGGgg.',
    '.gGGeGGeGGg.',
    'ggGGGGGGGGgg',
    'ggGGGmmGGGgg',
    'ggGGGGGGGGgg',
    '.gggggggggg.'], { g: '#2f8f4a', G: '#63d36f', e: '#10241a', m: '#10241a' })),
  finish(grid([
    '............',
    '....gggg....',
    '..ggGGGGgg..',
    '.gGGeGGeGGg.',
    'gGGGGGGGGGGg',
    'gGGGGmmGGGGg',
    'ggGGGGGGGGgg',
    'gggggggggggg'], { g: '#2f8f4a', G: '#63d36f', e: '#10241a', m: '#10241a' }))];

  const GHOUL = [
    '...bbbbbb...',
    '..bbbbbbbb..',
    '..bbKbbKbb..',
    '..bbKbbKbb..',
    '..bbbbbbbb..',
    '...bmmmmb...',
    '....bbbb....',
    '..rrrbbrrr..',
    '.rrrrbbrrrr.',
    '.brrrbbrrrb.',
    '.b.rrrrrr.b.',
    '...rrrrrr...',
    '...pp..pp...',
    '...pp..pp...',
    '..kkk..kkk..'];
  const GHOUL_B = GHOUL.slice(0, 12).concat(['....pppp....', '....pppp....', '...kkkkkk...']);
  const GP = { b: '#dcd5bb', K: '#e8402f', m: '#3a2a2a', r: '#7a3b3b', p: '#4a3a52', k: '#241a2a' };
  out.ghoul = [finish(grid(GHOUL, GP)), finish(grid(GHOUL_B, GP))];

  const BP = { b: '#c97b5a', K: '#ffe14a', m: '#3a1a1a', r: '#8a2f2f', p: '#4a2a2a', k: '#241414' };
  out.brute = [finish(grid(GHOUL, BP, 2)), finish(grid(GHOUL_B, BP, 2))];

  const KP = { b: '#b58cff', K: '#ffffff', m: '#2a1040', r: '#4a2a8a', p: '#2f1a5a', k: '#1a0f33' };
  out.boss = [finish(grid(GHOUL, KP, 3)), finish(grid(GHOUL_B, KP, 3))];
  const BOSSP = [KP,
    { b: '#9a958a', K: '#ffb23a', m: '#2a2620', r: '#5a564e', p: '#403c36', k: '#1f1c18' },
    { b: '#5fb07a', K: '#ffe14a', m: '#10261a', r: '#2f6a4a', p: '#1f4a35', k: '#0f2a1d' },
    { b: '#8fe9ff', K: '#ffffff', m: '#0b2a40', r: '#2a7ab0', p: '#1f4f80', k: '#0f2a4a' }];
  out.bosses = BOSSP.map(p => [finish(grid(GHOUL, p, 3)), finish(grid(GHOUL_B, p, 3))]);

  const GH = [
    '....wwww....',
    '..wwwwwwww..',
    '.wwwwwwwwww.',
    '.wwKKwwKKww.',
    '.wwKKwwKKww.',
    '.wwwwwmmwww.',
    '.wwwwwmmwww.',
    '.wwwwwwwwww.',
    '.wwwwwwwwww.',
    '.wwwwwwwwww.',
    '.ww.www.www.',
    'ww..ww..ww..'];
  const GHB = GH.slice(0, 10).concat(['.www.ww.www.', '.w..wwww..ww']);
  const GHP = { w: '#9ff3e6', K: '#0b2a33', m: '#0b2a33' };
  out.ghost = [finish(grid(GH, GHP)), finish(grid(GHB, GHP))];

  // летучая мышь — рисуем кадры вручную
  function bat(frame) {
    const c = mk(18, 10), x = c.getContext('2d');
    const wing = frame ? 0 : 3;
    x.fillStyle = '#5b3a8a';
    for (let i = 0; i < 6; i++) { x.fillRect(1 + i, 4 - (frame ? 0 : Math.min(i, 3)) + (i > 3 ? 1 : 0), 1, 3 + (frame ? i >> 1 : 0)); x.fillRect(16 - i, 4 - (frame ? 0 : Math.min(i, 3)) + (i > 3 ? 1 : 0), 1, 3 + (frame ? i >> 1 : 0)); }
    x.fillStyle = '#3a2260'; x.fillRect(7, 3, 4, 5);
    x.fillStyle = '#7a52b8'; x.fillRect(8, 3, 2, 2);
    x.fillStyle = '#ff5a5f'; x.fillRect(8, 5, 1, 1); x.fillRect(10, 5, 1, 1);
    x.fillStyle = '#3a2260'; x.fillRect(7, 2, 1, 2); x.fillRect(10, 2, 1, 2);
    return finish(c);
  }
  out.bat = [bat(0), bat(1)];

  // ---------- природа ----------
  function pine(seed, hue) {
    const r = mulberry(seed), c = mk(28, 40), x = c.getContext('2d');
    x.fillStyle = '#4a2f1b'; x.fillRect(12, 31, 5, 8); x.fillStyle = '#6b4527'; x.fillRect(12, 31, 2, 8);
    const pal = hue ? ['#16402c', '#1f6a4a', '#33946a', '#15332a'] : ['#1d5130', '#2a7a43', '#4fae5c', '#15391f'];
    const tiers = [[34, 14, 12], [26, 13, 10], [18, 13, 8], [10, 10, 5]];
    tiers.forEach(t => {
      const b = t[0], h = t[1], mh = t[2];
      for (let rr = 0; rr < h; rr++) {
        const half = Math.round(2 + rr * (mh - 2) / (h - 1)), y = b - h + rr + 1;
        for (let i = -half; i <= half; i++) {
          let col = pal[0];
          const rel = (i + half) / (2 * half + 1);
          if (rel < 0.38) col = pal[1];
          if (rel < 0.18 && r() < 0.7) col = pal[2];
          if (rr > h - 3) col = pal[3];
          if (r() < 0.08) col = pal[1];
          x.fillStyle = col; x.fillRect(14 + i, y, 1, 1);
        }
      }
    });
    return finish(c);
  }
  out.tree = [pine(11, 0), pine(23, 0), pine(37, 1)];

  function rock(seed) {
    const r = mulberry(seed), c = mk(18, 14), x = c.getContext('2d');
    const pal = ['#4a5062', '#6b7385', '#9aa3b8', '#cfd6e6'];
    for (let j = 0; j < 14; j++) for (let i = 0; i < 18; i++) {
      const dx = (i - 9) / 8.4, dy = (j - 8) / 6.2;
      if (dx * dx + dy * dy > 1) continue;
      const l = (-dx - dy) * 0.5 + 0.5 + (r() - 0.5) * 0.35;
      x.fillStyle = pal[l > 0.78 ? 3 : l > 0.5 ? 2 : l > 0.22 ? 1 : 0];
      x.fillRect(i, j, 1, 1);
    }
    return finish(c);
  }
  out.rock = [rock(5), rock(17), rock(29)];

  function crystal(seed) {
    const r = mulberry(seed), c = mk(16, 22), x = c.getContext('2d');
    function shard(cx, top, bot, hw) {
      for (let y = top; y <= bot; y++) {
        const t = (y - top) / (bot - top), half = Math.round(hw * (t < 0.45 ? t / 0.45 : 1 - (t - 0.45) / 0.55 * 0.35));
        for (let i = -half; i <= half; i++) {
          const rel = (i + half) / (2 * half + 1);
          x.fillStyle = rel < 0.3 ? '#c9f6ff' : rel < 0.65 ? '#5fd6ff' : '#2a8fd0';
          x.fillRect(cx + i, y, 1, 1);
        }
      }
    }
    shard(8, 1, 20, 4); shard(3, 8, 20, 2); shard(13, 10, 20, 2);
    x.fillStyle = '#fff'; x.fillRect(7, 4, 1, 4);
    return finish(c);
  }
  out.crystal = [crystal(1)];

  // ---------- постройки ----------
  function wall() {
    const c = mk(16, 18), x = c.getContext('2d');
    for (let i = 0; i < 4; i++) {
      const top = (i % 2) ? 3 : 1;
      x.fillStyle = '#7a5230'; x.fillRect(i * 4, top + 2, 3, 16 - top - 2);
      x.fillStyle = '#9a6b3e'; x.fillRect(i * 4, top + 2, 1, 16 - top - 2);
      x.fillStyle = '#5a3a1e'; x.fillRect(i * 4 + 2, top + 2, 1, 16 - top - 2);
      x.fillStyle = '#7a5230'; x.fillRect(i * 4 + 1, top, 1, 2);
      x.fillStyle = '#9a6b3e'; x.fillRect(i * 4 + 1, top, 1, 1);
    }
    x.fillStyle = '#c9a05a'; x.fillRect(0, 9, 15, 1); x.fillStyle = '#6b4a24'; x.fillRect(0, 10, 15, 1);
    x.fillStyle = '#c9a05a'; x.fillRect(0, 14, 15, 1);
    return finish(c);
  }
  out.wall = [wall()];

  function turret() {
    const c = mk(16, 20), x = c.getContext('2d');
    x.fillStyle = '#5a6074'; x.fillRect(1, 13, 14, 6);
    x.fillStyle = '#8f98ad'; x.fillRect(1, 13, 14, 2);
    x.fillStyle = '#3d4254'; x.fillRect(1, 17, 14, 2);
    x.fillStyle = '#7a5230'; x.fillRect(5, 6, 6, 8);
    x.fillStyle = '#9a6b3e'; x.fillRect(5, 6, 2, 8);
    x.fillStyle = '#c9a05a'; x.fillRect(4, 5, 8, 2);
    x.fillStyle = '#2a6f8f'; x.fillRect(5, 0, 6, 6);
    x.fillStyle = '#5fd6ff'; x.fillRect(6, 1, 4, 4);
    x.fillStyle = '#e9ffff'; x.fillRect(6, 1, 2, 2);
    return finish(c);
  }
  out.turret = [turret()];

  function torch() {
    const c = mk(8, 20), x = c.getContext('2d');
    x.fillStyle = '#6b4527'; x.fillRect(3, 6, 2, 13); x.fillStyle = '#9a6b3e'; x.fillRect(3, 6, 1, 13);
    x.fillStyle = '#3d4254'; x.fillRect(1, 5, 6, 2);
    x.fillStyle = '#5a6074'; x.fillRect(1, 5, 6, 1);
    x.fillStyle = '#4a2f1b'; x.fillRect(2, 17, 4, 2);
    return finish(c);
  }
  out.torch = [torch()];

  out.logs = [finish((function () {
    const c = mk(22, 10), x = c.getContext('2d');
    function log(x0, y0, dx, dy) {
      for (let i = 0; i < 12; i++) { const px = x0 + Math.round(i * dx), py = y0 + Math.round(i * dy); x.fillStyle = '#6b4527'; x.fillRect(px, py, 3, 3); x.fillStyle = '#9a6b3e'; x.fillRect(px, py, 3, 1); }
      x.fillStyle = '#d9a064'; x.fillRect(x0 + Math.round(11 * dx), y0 + Math.round(11 * dy), 3, 3);
    }
    log(2, 1, 1.5, 0.6); log(2, 8, 1.5, -0.6);
    x.fillStyle = '#6b7385'; for (let i = 0; i < 11; i++) { const a = i / 11 * Math.PI * 2; x.fillRect(11 + Math.round(Math.cos(a) * 10), 5 + Math.round(Math.sin(a) * 4), 2, 2); }
    x.fillStyle = '#9aa3b8'; for (let i = 0; i < 11; i += 2) { const a = i / 11 * Math.PI * 2; x.fillRect(11 + Math.round(Math.cos(a) * 10), 5 + Math.round(Math.sin(a) * 4), 1, 1); }
    return c;
  })())];

  // ---------- иконки интерфейса ----------
  const I = {
    wood: [['..dddd..', '.dBBBBd.', 'dBBllBBd', 'dBlBBlBd', 'dBlBBlBd', 'dBBllBBd', '.dBBBBd.', '..dddd..'], { d: '#5a3a1e', B: '#a9733c', l: '#d9a064' }],
    stone: [['........', '..gggg..', '.gGGGGg.', 'gGGlGGGg', 'gGGGGGGg', 'gGGGGGdg', '.gddddg.', '..gggg..'], { g: '#6b7385', G: '#9aa3b8', l: '#cfd6e6', d: '#4a5062' }],
    crystal: [['...cc...', '..cCCc..', '.cCwCCc.', '.cCwCCc.', '..cCCc..', '..cCCc..', '...cc...', '........'], { c: '#2a9dd8', C: '#6fe3ff', w: '#ffffff' }],
    heart: [['.rr..rr.', 'rRRrrrrr', 'rRRrrrrr', 'rrrrrrrr', '.rrrrrr.', '..rrrr..', '...rr...', '........'], { r: '#e0394a', R: '#ff8a94' }],
    flame: [['...o....', '..oo..o.', '..ooo.oo', '.oooyooo', '.ooyyyoo', '.oyyyyyo', '..oyyyo.', '...ooo..'], { o: '#ff7a1a', y: '#ffd54a' }],
    coin: [['..gggg..', '.gYYYYg.', 'gYYwwYYg', 'gYwYYYYg', 'gYwYYYYg', 'gYYYYYYg', '.gYYYYg.', '..gggg..'], { g: '#b8860b', Y: '#ffd447', w: '#fff3b0' }],
    hammer: [['.gggggg.', '.gGGGGg.', '.gggggg.', '...bb...', '...bb...', '...bb...', '...bb...', '...bb...'], { g: '#6b7385', G: '#cfd6e6', b: '#9a6b3e' }]
  };
  out.icon = {};
  Object.keys(I).forEach(k => { out.icon[k] = grid(I[k][0], I[k][1], 1); });
  out.url = function (c) { return c.toDataURL(); };
  out.iconURL = {};
  Object.keys(out.icon).forEach(k => { out.iconURL[k] = out.icon[k].toDataURL(); });
  out.iconURL.wall = out.wall[0].c.toDataURL();
  out.iconURL.turret = out.turret[0].c.toDataURL();
  out.iconURL.torch = out.torch[0].c.toDataURL();

  // ---------- земля ----------
  function ground() {
    const S = 96, c = mk(S, S), x = c.getContext('2d'), r = mulberry(7);
    x.fillStyle = '#3d8142'; x.fillRect(0, 0, S, S);
    const tones = ['#438a48', '#377a3c', '#4a9450', '#33703a'];
    for (let i = 0; i < 420; i++) { x.fillStyle = tones[(r() * 4) | 0]; x.fillRect((r() * S) | 0, (r() * S) | 0, r() < 0.3 ? 2 : 1, 1); }
    for (let i = 0; i < 26; i++) { // пучки травы
      const px = (r() * (S - 4)) | 0, py = (r() * (S - 4)) | 0;
      x.fillStyle = '#2c6a35'; x.fillRect(px, py + 1, 1, 2); x.fillRect(px + 2, py, 1, 3); x.fillRect(px + 4, py + 1, 1, 2);
      x.fillStyle = '#5fb060'; x.fillRect(px + 2, py, 1, 1);
    }
    const fl = ['#ffffff', '#ff8fb8', '#ffd447', '#9fd7ff'];
    for (let i = 0; i < 9; i++) { const px = (r() * (S - 2)) | 0, py = (r() * (S - 2)) | 0; x.fillStyle = fl[(r() * 4) | 0]; x.fillRect(px, py, 1, 1); x.fillStyle = '#2c6a35'; x.fillRect(px, py + 1, 1, 1); }
    return c;
  }
  out.ground = ground();

  function dirt() {
    const w = 120, h = 84, c = mk(w, h), x = c.getContext('2d'), r = mulberry(3);
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const dx = (i - w / 2) / (w / 2), dy = (j - h / 2) / (h / 2), d = dx * dx + dy * dy + (r() - 0.5) * 0.12;
      if (d > 1) continue;
      x.fillStyle = d > 0.82 ? '#5d4630' : d > 0.5 ? '#4f3a28' : '#43321f';
      x.fillRect(i, j, 1, 1);
    }
    for (let i = 0; i < 40; i++) { const a = r() * 6.28, rr = r() * 0.85; x.fillStyle = r() < 0.5 ? '#6b7385' : '#2f2316'; x.fillRect((w / 2 + Math.cos(a) * rr * w / 2) | 0, (h / 2 + Math.sin(a) * rr * h / 2) | 0, 1, 1); }
    return c;
  }
  out.dirt = dirt();

  // ---------- свет ----------
  function lightSprite(rgb, stops) {
    const c = mk(128, 128), x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
    stops.forEach(s => g.addColorStop(s[0], 'rgba(' + rgb + ',' + s[1] + ')'));
    x.fillStyle = g; x.fillRect(0, 0, 128, 128); return c;
  }
  out.cut = lightSprite('255,255,255', [[0, 1], [0.3, 0.88], [0.6, 0.45], [0.85, 0.12], [1, 0]]);
  out.warm = lightSprite('255,150,60', [[0, 0.55], [0.35, 0.28], [0.7, 0.08], [1, 0]]);
  out.cool = lightSprite('90,210,255', [[0, 0.5], [0.4, 0.22], [0.8, 0.05], [1, 0]]);
  out.purple = lightSprite('170,90,255', [[0, 0.5], [0.4, 0.22], [0.8, 0.05], [1, 0]]);

  // ---------- новые стены ----------
  out.stonewall = [finish((function () {
    const c = mk(16, 17), x = c.getContext('2d');
    for (let j = 0; j < 3; j++) {
      const y = 3 + j * 5, off = (j % 2) ? 4 : 0;
      x.fillStyle = '#8a93a8'; x.fillRect(0, y, 16, 4); x.fillStyle = '#b8c1d6'; x.fillRect(0, y, 16, 1);
      x.fillStyle = '#5a6074'; x.fillRect(0, y + 4, 16, 1);
      for (let i = -1; i < 3; i++) { x.fillStyle = '#5a6074'; x.fillRect(off + i * 8 + 4, y, 1, 4); }
    }
    x.fillStyle = '#8a93a8'; for (let i = 0; i < 4; i++) { x.fillRect(i * 4, 0, 3, 3); }
    x.fillStyle = '#b8c1d6'; for (let i = 0; i < 4; i++) { x.fillRect(i * 4, 0, 3, 1); }
    return c;
  })())];

  out.spikewall = [finish((function () {
    const c = mk(16, 21), x = c.getContext('2d');
    for (let i = 0; i < 4; i++) {
      const cx = i * 4 + 1;
      x.fillStyle = '#6b4527'; x.fillRect(i * 4, 6, 3, 15); x.fillStyle = '#9a6b3e'; x.fillRect(i * 4, 6, 1, 15);
      x.fillStyle = '#a8b2c8'; x.fillRect(cx - 1, 3, 3, 3); x.fillRect(cx, 1, 1, 2);
      x.fillStyle = '#eef2ff'; x.fillRect(cx, 1, 1, 2); x.fillStyle = '#e0394a'; x.fillRect(cx, 0, 1, 1);
    }
    x.fillStyle = '#5a6074'; x.fillRect(0, 12, 15, 1); x.fillRect(0, 17, 15, 1);
    x.fillStyle = '#cfd6e6'; for (let i = 0; i < 3; i++) { x.fillRect(i * 4 + 3, 11, 1, 1); x.fillRect(i * 4 + 3, 16, 1, 1); }
    return c;
  })())];

  out.cwall = [finish((function () {
    const c = mk(16, 22), x = c.getContext('2d');
    x.fillStyle = '#3a4a7a'; x.fillRect(0, 10, 16, 12); x.fillStyle = '#5a6aa8'; x.fillRect(0, 10, 16, 2); x.fillStyle = '#2a3560'; x.fillRect(0, 20, 16, 2);
    x.fillStyle = '#2a3560'; x.fillRect(5, 12, 1, 8); x.fillRect(10, 12, 1, 8);
    function shard(cx, top, bot, hw) {
      for (let y = top; y <= bot; y++) {
        const t = (y - top) / (bot - top), half = Math.round(hw * (t < 0.4 ? t / 0.4 : 1 - (t - 0.4) / 0.6 * 0.2));
        for (let i = -half; i <= half; i++) { const rel = (i + half) / (2 * half + 1); x.fillStyle = rel < 0.3 ? '#c9f6ff' : rel < 0.65 ? '#5fd6ff' : '#2a8fd0'; x.fillRect(cx + i, y, 1, 1); }
      }
    }
    shard(8, 0, 11, 3); shard(3, 4, 11, 2); shard(13, 5, 11, 2);
    return c;
  })())];

  // ---------- артиллерия ----------
  out.ballista = [finish((function () {
    const c = mk(20, 19), x = c.getContext('2d');
    x.fillStyle = '#5a3a1e'; x.fillRect(2, 13, 16, 5); x.fillStyle = '#9a6b3e'; x.fillRect(2, 13, 16, 1); x.fillStyle = '#3d2a16'; x.fillRect(3, 17, 3, 2); x.fillRect(14, 17, 3, 2);
    x.fillStyle = '#8a5a2e';
    const arm = [[1, 9], [1, 8], [2, 7], [3, 6], [4, 5], [5, 5], [6, 5]];
    arm.forEach(p => { x.fillRect(p[0], p[1], 2, 2); x.fillRect(19 - p[0] - 1, p[1], 2, 2); });
    x.fillStyle = '#e8d8a8'; x.fillRect(3, 11, 14, 1);
    x.fillStyle = '#7a5230'; x.fillRect(9, 6, 2, 8); x.fillStyle = '#c9a05a'; x.fillRect(9, 6, 1, 8);
    x.fillStyle = '#cfd6e6'; x.fillRect(9, 2, 2, 5); x.fillStyle = '#ffffff'; x.fillRect(9, 1, 2, 2);
    return c;
  })())];

  out.mortar = [finish((function () {
    const c = mk(18, 18), x = c.getContext('2d');
    x.fillStyle = '#5a6074'; x.fillRect(1, 12, 16, 6); x.fillStyle = '#8f98ad'; x.fillRect(1, 12, 16, 2); x.fillStyle = '#3d4254'; x.fillRect(1, 16, 16, 2);
    x.fillStyle = '#3d4254'; x.fillRect(5, 3, 8, 10); x.fillStyle = '#6b7385'; x.fillRect(5, 3, 2, 10);
    x.fillStyle = '#8f98ad'; x.fillRect(4, 1, 10, 3); x.fillStyle = '#0e1120'; x.fillRect(6, 1, 6, 2);
    x.fillStyle = '#c9a05a'; x.fillRect(5, 8, 8, 1);
    x.fillStyle = '#c9a05a'; x.fillRect(14, 13, 2, 2); x.fillRect(1, 13, 2, 2); x.fillStyle = '#ffe08a'; x.fillRect(14, 13, 1, 1); x.fillRect(1, 13, 1, 1);
    return c;
  })())];

  out.flamer = [finish((function () {
    const c = mk(17, 19), x = c.getContext('2d');
    x.fillStyle = '#5a3a1e'; x.fillRect(1, 15, 15, 4); x.fillStyle = '#9a6b3e'; x.fillRect(1, 15, 15, 1);
    x.fillStyle = '#a83a2a'; x.fillRect(2, 6, 9, 10); x.fillStyle = '#d9583a'; x.fillRect(3, 7, 2, 8); x.fillStyle = '#7a2a1e'; x.fillRect(2, 14, 9, 2);
    x.fillStyle = '#ffd447'; x.fillRect(5, 9, 3, 3); x.fillStyle = '#7a5a10'; x.fillRect(5, 9, 3, 1);
    x.fillStyle = '#3d4254'; x.fillRect(10, 9, 6, 4); x.fillStyle = '#6b7385'; x.fillRect(10, 9, 6, 1); x.fillStyle = '#0e1120'; x.fillRect(15, 10, 1, 2);
    x.fillStyle = '#8f98ad'; x.fillRect(4, 3, 4, 3);
    return c;
  })())];

  out.tower = [finish((function () {
    const c = mk(14, 30), x = c.getContext('2d');
    const half = [0, 1, 2, 3, 3, 3, 3, 2, 2, 1, 0];
    for (let y = 0; y < half.length; y++) for (let i = -half[y]; i <= half[y]; i++) { const rel = (i + half[y]) / (2 * half[y] + 1); x.fillStyle = rel < 0.3 ? '#c9f6ff' : rel < 0.65 ? '#5fd6ff' : '#2a8fd0'; x.fillRect(7 + i, y, 1, 1); }
    x.fillStyle = '#ffffff'; x.fillRect(6, 3, 1, 4);
    x.fillStyle = '#8a93a8'; x.fillRect(3, 11, 8, 15); x.fillStyle = '#b8c1d6'; x.fillRect(3, 11, 2, 15); x.fillStyle = '#5a6074'; x.fillRect(9, 11, 2, 15);
    x.fillStyle = '#4a5062'; x.fillRect(3, 15, 8, 1); x.fillRect(3, 20, 8, 1);
    x.fillStyle = '#2a8fd0'; x.fillRect(5, 17, 4, 2);
    x.fillStyle = '#6b7385'; x.fillRect(1, 25, 12, 5); x.fillStyle = '#8f98ad'; x.fillRect(1, 25, 12, 2); x.fillStyle = '#3d4254'; x.fillRect(1, 28, 12, 2);
    return c;
  })())];

  // ---------- руины и сундуки ----------
  function chest(open) {
    const c = mk(14, 13), x = c.getContext('2d');
    x.fillStyle = '#6b3f1c'; x.fillRect(1, 6, 12, 7); x.fillStyle = '#9a5f2c'; x.fillRect(1, 6, 12, 1);
    if (!open) {
      x.fillStyle = '#a0652e'; x.fillRect(0, 2, 14, 5); x.fillStyle = '#c98a45'; x.fillRect(0, 2, 14, 1); x.fillStyle = '#7a4a22'; x.fillRect(0, 6, 14, 1);
    } else {
      x.fillStyle = '#2a1a0e'; x.fillRect(2, 6, 10, 2); x.fillStyle = '#ffd447'; x.fillRect(3, 6, 2, 1); x.fillRect(8, 6, 3, 1); x.fillRect(6, 5, 1, 1);
      x.fillStyle = '#7a4a22'; x.fillRect(0, 0, 14, 3); x.fillStyle = '#a0652e'; x.fillRect(0, 0, 14, 1);
    }
    x.fillStyle = '#e0b45e'; x.fillRect(3, 2, 2, 11); x.fillRect(9, 2, 2, 11);
    if (!open) { x.fillStyle = '#ffd447'; x.fillRect(6, 6, 2, 3); x.fillStyle = '#7a5a10'; x.fillRect(6, 8, 2, 1); }
    return finish(c);
  }
  out.chest = [chest(false), chest(true)];

  function pillar(h, broken, seed) {
    const r = mulberry(seed), c = mk(12, h), x = c.getContext('2d');
    for (let y = 0; y < h; y++) for (let i = 0; i < 10; i++) {
      if (broken && y < 3 && (i + y) % 3 === 0) continue;
      const rel = i / 10; x.fillStyle = rel < 0.25 ? '#b8c1d6' : rel < 0.65 ? '#8a93a8' : '#5a6074'; x.fillRect(1 + i, y, 1, 1);
      if (r() < 0.07) { x.fillStyle = '#3f7a42'; x.fillRect(1 + i, y, 1, 1); }
    }
    x.fillStyle = '#6b7385'; x.fillRect(0, 0, 12, 2); x.fillRect(0, h - 3, 12, 3);
    x.fillStyle = '#b8c1d6'; x.fillRect(0, h - 3, 12, 1);
    x.fillStyle = '#3f7a42'; x.fillRect(1, 4, 2, 1); x.fillRect(7, h - 6, 3, 1);
    return finish(c);
  }
  out.pillar = [pillar(28, false, 3), pillar(17, true, 9)];
  out.rubble = [finish((function () {
    const r = mulberry(5), c = mk(18, 8), x = c.getContext('2d');
    for (let k = 0; k < 7; k++) { const px = 1 + r() * 13, py = 2 + r() * 4, w = 2 + r() * 3; x.fillStyle = '#8a93a8'; x.fillRect(px | 0, py | 0, w | 0, 2); x.fillStyle = '#b8c1d6'; x.fillRect(px | 0, py | 0, w | 0, 1); }
    return c;
  })())];

  // ---------- земля биомов ----------
  function groundVar(o) {
    const S = 96, c = mk(S, S), x = c.getContext('2d'), r = mulberry(o.seed);
    x.fillStyle = o.base; x.fillRect(0, 0, S, S);
    for (let i = 0; i < 420; i++) { x.fillStyle = o.tones[(r() * o.tones.length) | 0]; x.fillRect((r() * S) | 0, (r() * S) | 0, r() < 0.3 ? 2 : 1, 1); }
    o.extra(x, r, S);
    return c;
  }
  out.groundStony = groundVar({ seed: 21, base: '#6f6a62', tones: ['#77726a', '#625d56', '#827d74', '#58534c'], extra: function (x, r, S) {
    for (let i = 0; i < 14; i++) { const px = (r() * (S - 6)) | 0, py = (r() * (S - 5)) | 0, w = 2 + ((r() * 3) | 0); x.fillStyle = '#4a463f'; x.fillRect(px, py + 2, w + 1, 1); x.fillStyle = '#9a958b'; x.fillRect(px, py, w, 2); x.fillStyle = '#b4afa4'; x.fillRect(px, py, w, 1); }
    for (let i = 0; i < 9; i++) { let px = (r() * S) | 0, py = (r() * S) | 0; x.fillStyle = '#4a463f'; for (let k = 0; k < 6; k++) { x.fillRect(px, py, 1, 1); px += (r() < 0.6 ? 1 : 0); py += (r() < 0.5 ? 1 : 0); } }
    for (let i = 0; i < 8; i++) { const px = (r() * (S - 4)) | 0, py = (r() * (S - 4)) | 0; x.fillStyle = '#8a8a50'; x.fillRect(px, py + 1, 1, 2); x.fillRect(px + 2, py, 1, 3); }
  } });
  out.groundCrystal = groundVar({ seed: 33, base: '#3a386a', tones: ['#43417a', '#33315c', '#4b4885', '#2b2950'], extra: function (x, r, S) {
    for (let i = 0; i < 60; i++) { const px = (r() * S) | 0, py = (r() * S) | 0; x.fillStyle = r() < 0.6 ? '#6fe3ff' : '#c9a8ff'; x.fillRect(px, py, 1, 1); if (r() < 0.2) { x.fillRect(px - 1, py, 1, 1); x.fillRect(px + 1, py, 1, 1); x.fillRect(px, py - 1, 1, 1); x.fillRect(px, py + 1, 1, 1); } }
    for (let i = 0; i < 10; i++) { const px = (r() * (S - 4)) | 0, py = (r() * (S - 6)) | 0; x.fillStyle = '#2a8fd0'; x.fillRect(px + 1, py + 2, 2, 3); x.fillStyle = '#6fe3ff'; x.fillRect(px + 1, py, 1, 3); x.fillRect(px + 2, py + 1, 1, 2); x.fillStyle = '#e9ffff'; x.fillRect(px + 1, py + 1, 1, 1); }
  } });
  out.groundSwamp = groundVar({ seed: 47, base: '#2d5646', tones: ['#356450', '#274b3d', '#3a6c58', '#213f34'], extra: function (x, r, S) {
    for (let i = 0; i < 5; i++) {
      const px = ((r() * (S - 22)) | 0) + 4, py = ((r() * (S - 12)) | 0) + 3, w = 12 + ((r() * 8) | 0), h = 5 + ((r() * 3) | 0);
      for (let j = 0; j < h; j++) for (let k = 0; k < w; k++) { const dx = (k - w / 2) / (w / 2), dy = (j - h / 2) / (h / 2), d = dx * dx + dy * dy; if (d > 1) continue; x.fillStyle = d > 0.78 ? '#3d7a74' : d > 0.25 ? '#1e3d3e' : '#2a5256'; x.fillRect(px + k, py + j, 1, 1); }
      x.fillStyle = '#9ad8d0'; x.fillRect(px + 3, py + 1, 2, 1);
    }
    for (let i = 0; i < 12; i++) { const px = (r() * (S - 3)) | 0, py = (r() * (S - 6)) | 0; x.fillStyle = '#5a8a4a'; x.fillRect(px, py + 1, 1, 4); x.fillRect(px + 2, py + 2, 1, 3); x.fillStyle = '#8a5a2e'; x.fillRect(px, py, 1, 2); }
    for (let i = 0; i < 4; i++) { const px = (r() * (S - 3)) | 0, py = (r() * (S - 3)) | 0; x.fillStyle = '#e9e4d0'; x.fillRect(px, py + 1, 2, 1); x.fillStyle = '#e0394a'; x.fillRect(px, py, 2, 1); }
  } });

  out.iconURL.stonewall = out.stonewall[0].c.toDataURL();
  out.iconURL.spikewall = out.spikewall[0].c.toDataURL();
  out.iconURL.cwall = out.cwall[0].c.toDataURL();
  out.iconURL.ballista = out.ballista[0].c.toDataURL();
  out.iconURL.mortar = out.mortar[0].c.toDataURL();
  out.iconURL.flamer = out.flamer[0].c.toDataURL();
  out.iconURL.tower = out.tower[0].c.toDataURL();

  // ---------- новые руды ----------
  function ore(seed, pal, vein) {
    const r = mulberry(seed), c = mk(18, 14), x = c.getContext('2d');
    for (let j = 0; j < 14; j++) for (let i = 0; i < 18; i++) {
      const dx = (i - 9) / 8.4, dy = (j - 8) / 6.2; if (dx * dx + dy * dy > 1 + (r() - 0.5) * 0.15) continue;
      const l = (-dx - dy) * 0.5 + 0.5 + (r() - 0.5) * 0.3; x.fillStyle = pal[l < 0.3 ? 0 : l < 0.55 ? 1 : l < 0.8 ? 2 : 3]; x.fillRect(i, j, 1, 1);
    }
    for (let k = 0; k < 9; k++) { const px = 3 + ((r() * 11) | 0), py = 3 + ((r() * 7) | 0); x.fillStyle = vein[0]; x.fillRect(px, py, 2, 2); x.fillStyle = vein[1]; x.fillRect(px, py, 1, 1); }
    return finish(c);
  }
  out.iron = [ore(11, ['#3d4048', '#5a5e6a', '#7c818f', '#a5aab8'], ['#d9783a', '#ffb47a'])];
  out.gold = [ore(17, ['#4a4030', '#6b5d3e', '#8a7a52', '#b0a070'], ['#ffd447', '#fff3b0'])];

  out.ironwall = [finish((function () {
    const c = mk(16, 17), x = c.getContext('2d');
    x.fillStyle = '#4a4f5c'; x.fillRect(0, 2, 16, 15); x.fillStyle = '#7c818f'; x.fillRect(0, 2, 16, 3); x.fillStyle = '#2a2d36'; x.fillRect(0, 14, 16, 3);
    x.fillStyle = '#2a2d36'; x.fillRect(0, 8, 16, 1);
    [[2, 5], [12, 5], [2, 11], [12, 11]].forEach(p => { x.fillStyle = '#c9ced9'; x.fillRect(p[0], p[1], 2, 2); x.fillStyle = '#2a2d36'; x.fillRect(p[0] + 1, p[1] + 1, 1, 1); });
    x.fillStyle = '#d9783a'; x.fillRect(6, 9, 4, 1);
    for (let i = 0; i < 4; i++) { x.fillStyle = '#7c818f'; x.fillRect(i * 4 + 1, 0, 3, 2); }
    return c;
  })())];
  out.goldwall = [finish((function () {
    const c = mk(16, 19), x = c.getContext('2d');
    x.fillStyle = '#8a6a1a'; x.fillRect(0, 4, 16, 15); x.fillStyle = '#ffd447'; x.fillRect(0, 4, 16, 3); x.fillStyle = '#5a430e'; x.fillRect(0, 16, 16, 3);
    x.fillStyle = '#b8901e'; x.fillRect(1, 8, 6, 7); x.fillRect(9, 8, 6, 7); x.fillStyle = '#fff3b0'; x.fillRect(2, 9, 2, 1); x.fillRect(10, 9, 2, 1);
    for (let i = 0; i < 3; i++) { x.fillStyle = '#ffd447'; x.fillRect(1 + i * 5, 1, 4, 3); x.fillStyle = '#fff3b0'; x.fillRect(1 + i * 5, 1, 4, 1); }
    x.fillStyle = '#6fe3ff'; x.fillRect(7, 10, 2, 3); x.fillStyle = '#fff'; x.fillRect(7, 10, 1, 1);
    return c;
  })())];

  out.tesla = [finish((function () {
    const c = mk(16, 28), x = c.getContext('2d');
    x.fillStyle = '#4a4f5c'; x.fillRect(2, 20, 12, 8); x.fillStyle = '#7c818f'; x.fillRect(2, 20, 12, 2); x.fillStyle = '#2a2d36'; x.fillRect(2, 26, 12, 2);
    x.fillStyle = '#b87a3a'; x.fillRect(6, 8, 4, 13); x.fillStyle = '#e0a060'; x.fillRect(6, 8, 1, 13);
    for (let k = 0; k < 4; k++) { x.fillStyle = '#7a4a22'; x.fillRect(5, 10 + k * 3, 6, 1); }
    x.fillStyle = '#7c818f'; x.fillRect(4, 5, 8, 4); x.fillStyle = '#c9ced9'; x.fillRect(4, 5, 8, 1);
    x.fillStyle = '#6fe3ff'; x.fillRect(5, 0, 6, 5); x.fillStyle = '#c9f6ff'; x.fillRect(6, 1, 3, 2); x.fillStyle = '#fff'; x.fillRect(6, 1, 1, 1);
    x.fillStyle = '#6fe3ff'; x.fillRect(1, 12, 1, 3); x.fillRect(14, 12, 1, 3); x.fillRect(0, 14, 1, 1); x.fillRect(15, 14, 1, 1);
    return c;
  })())];
  out.rocket = [finish((function () {
    const c = mk(20, 22), x = c.getContext('2d');
    x.fillStyle = '#4a3a2a'; x.fillRect(1, 16, 18, 6); x.fillStyle = '#7a5a3a'; x.fillRect(1, 16, 18, 1); x.fillStyle = '#2a1f14'; x.fillRect(1, 20, 18, 2);
    x.fillStyle = '#5a6074'; x.fillRect(3, 6, 14, 11); x.fillStyle = '#8f98ad'; x.fillRect(3, 6, 14, 2); x.fillStyle = '#3d4254'; x.fillRect(3, 15, 14, 2);
    for (let i = 0; i < 3; i++) { x.fillStyle = '#0e1120'; x.fillRect(4 + i * 4, 8, 3, 6); x.fillStyle = '#e0394a'; x.fillRect(4 + i * 4, 4, 3, 4); x.fillStyle = '#ff8a94'; x.fillRect(4 + i * 4, 4, 1, 3); x.fillStyle = '#fff'; x.fillRect(5 + i * 4, 3, 1, 1); }
    x.fillStyle = '#d9783a'; x.fillRect(2, 11, 1, 3); x.fillRect(17, 11, 1, 3);
    return c;
  })())];
  out.laser = [finish((function () {
    const c = mk(16, 26), x = c.getContext('2d');
    x.fillStyle = '#2a2d36'; x.fillRect(2, 20, 12, 6); x.fillStyle = '#5a5e6a'; x.fillRect(2, 20, 12, 2);
    x.fillStyle = '#7c818f'; x.fillRect(5, 9, 6, 12); x.fillStyle = '#c9ced9'; x.fillRect(5, 9, 1, 12); x.fillStyle = '#3d4048'; x.fillRect(10, 9, 1, 12);
    x.fillStyle = '#ffd447'; x.fillRect(4, 13, 8, 2);
    x.fillStyle = '#e0394a'; x.fillRect(4, 3, 8, 7); x.fillStyle = '#ff8a94'; x.fillRect(5, 4, 3, 2); x.fillStyle = '#7a1a22'; x.fillRect(4, 9, 8, 1);
    x.fillStyle = '#0e1120'; x.fillRect(6, 5, 4, 3); x.fillStyle = '#ff3b3b'; x.fillRect(7, 6, 2, 1);
    x.fillStyle = '#ffd447'; x.fillRect(7, 0, 2, 3);
    return c;
  })())];
  I.iron = [['........', '..gggg..', '.gGGGGg.', 'gGoGGGGg', 'gGGGGoGg', 'gGGoGGGg', '.gddddg.', '..gggg..'], { g: '#4a4f5c', G: '#7c818f', o: '#ff9a4a', d: '#2a2d36' }];
  I.gold = [['........', '..gggg..', '.gGGGGg.', 'gGyyGGGg', 'gGGGGyyg', 'gGyGGGGg', '.gddddg.', '..gggg..'], { g: '#6b5d3e', G: '#8a7a52', y: '#ffd447', d: '#4a4030' }];
  out.icon.iron = grid(I.iron[0], I.iron[1], 1); out.icon.gold = grid(I.gold[0], I.gold[1], 1);
  out.iconURL.iron = out.icon.iron.toDataURL(); out.iconURL.gold = out.icon.gold.toDataURL();
  ['ironwall', 'goldwall', 'tesla', 'rocket', 'laser'].forEach(k => { out.iconURL[k] = out[k][0].c.toDataURL(); });

  // ---------- питомцы ----------
  const WOLF_A = ['..........g.g.', '..ggggggggggg.', '.gggGGggggggkg', '.gggGGgggggggg', 'ggggggggggggg.', '.wwwwwwwwwww..', '.gg.gg..gg.gg.', '.gg.gg..gg.gg.'];
  const WOLF_B = WOLF_A.slice(0, 6).concat(['..gg.gg.gg.gg.', '..gg.gg.gg.gg.']);
  const WP = { g: '#8a8f9c', G: '#b8bdca', k: '#1a1a2e', w: '#d9dce6' };
  const DR_A = ['.rrr...rrr.', '...bbbbb...', '..bbBBBbb..', '.bbBeeeBbb.', '..bbBBBbb..', '...bbbbb...', '....y.y....'];
  const DR_B = ['rrr.....rrr'].concat(DR_A.slice(1));
  const DP = { r: '#cfd6e6', b: '#4b5668', B: '#6b7a8f', e: '#6fe3ff', y: '#ffd447' };
  const FA_A = ['...hhh...', '..hhhhh..', '..hsesh..', 'w..sss..w', 'ww.ddd.ww', 'www.d.www', '.ww.d.ww.', '...d.d...'];
  const FA_B = FA_A.slice(0, 3).concat(['.w.sss.w.', '.w.ddd.w.', 'ww..d..ww', '.w..d..w.', '...d.d...']);
  const FP = { h: '#ff8fd0', s: '#f6d0b0', e: '#1a1a2e', d: '#7dff8f', w: '#d9f6ff' };
  out.pets = { wolf: [finish(grid(WOLF_A, WP)), finish(grid(WOLF_B, WP))], drone: [finish(grid(DR_A, DP)), finish(grid(DR_B, DP))], fairy: [finish(grid(FA_A, FP)), finish(grid(FA_B, FP))] };

  // превью героя для меню (в DOM)
  out.heroPreview = function (id) { return out.hero[id][0].c; };

  // ---- v1.4: новые монстры, торговец, рыба
  {
    function two(rows, pal, alt) { const b = rows.slice(), a = rows.slice(); alt.forEach((r, i) => { a[a.length - alt.length + i] = r; }); return [finish(grid(b, pal)), finish(grid(a, pal))]; }
    out.mons = {};
    out.mons.archer = two(['....hhhh....', '...hhhhhh...', '..hhffffhh..', '..hhfeefhh..', '...hffffh...', '..wbbbbbb...', '.w.bbbbbb...', 'w..bbbbbb...', '.w.bbbbbb...', '..wbbbbbb...', '....bbbb....', '....bbbb....', '....k..k....'], { h: '#3d7a4a', f: '#d9d2b0', e: '#101018', w: '#a0703a', b: '#2f5a3a', k: '#2a2a2a' }, ['...kk..kk...']);
    out.mons.boomer = two(['......ys....', '.....y......', '...dddddd...', '..dooddddd..', '.ddoddddddd.', '.ddyydyyddd.', '.dddddddddd.', '.dddrrrrddd.', '.dddddddddd.', '..dddddddd..', '...dddddd...', '....k..k....'], { d: '#6b2a1a', o: '#e0734a', y: '#ffd447', s: '#ff9a3a', r: '#2a0a08', k: '#222' }, ['...kk..kk...']);
    out.mons.stalker = two(['....pppp....', '...pppppp...', '..ppeppepp..', '..pppppppp..', '...pppppp...', '..pppppppp..', '.pp.pppp.pp.', '.p..pppp..p.', '....pppp....', '....p..p....', '...pp..pp...'], { p: '#4a2f78', e: '#ff4a6a' }, ['....p..p....', '....pp.pp...']);
    out.mons.shaman = two(['g...hhhh....', 's..hhhhhh...', 's..hffffh...', 's..hfeefh...', 's...hhhh....', 's..rrrrrr...', 's.rrrrrrrr..', 's.rrrbbrrr..', 's.rrrrrrrr..', 's.rrrrrrrr..', '..rrrrrrrr..', '..kk....kk..'], { h: '#2f8f7a', f: '#cfeedd', e: '#101018', r: '#2a6f6a', b: '#c9a05a', s: '#8a5a2a', g: '#7dff8f', k: '#222' }, ['..k......k..']);
    const TR = ['....rrrr....', '...rrrrrr...', '..rrffffrr..', '..rrfeefrr..', '..rrffffrr..', '...rrffrr...', '..bbrrrrbb..', '.bbbrrrrbbb.', '.bbbrrrrbbb.', '.bbbbrrbbbb.', '..bbrrrrbb..', '..bbrrrrbb..', '..kk....kk..', '.kkk....kkk.'];
    out.trader = finish(grid(TR, { r: '#7a3b8f', f: '#e0b48a', e: '#1a1020', b: '#c98a3a', k: '#3a2a1a' }));
    const FI = ['........', '..bbbb.b', '.bBBBBbb', 'bBeBBBbb', 'bBBBBBbb', '.bBBBBbb', '..bbbb.b', '........'];
    out.icon.fish = grid(FI, { b: '#3a6f9a', B: '#8fd0f0', e: '#10202c' }, 1); out.iconURL.fish = out.icon.fish.toDataURL();
  }
  return out;
})();
