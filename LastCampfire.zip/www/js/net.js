/* Nyxvault · Последний костёр — транспорт LAN.
   В APK: нативный плагин LanNet (TCP + UDP-обнаружение, привязка к Wi-Fi сети).
   В обычном браузере: тестовый канал BroadcastChannel (только между вкладками одного устройства). */
(function () {
  'use strict';
  const PORT = 47770, DISC = 47771;
  const cap = window.Capacitor, plug = cap && cap.Plugins && cap.Plugins.LanNet;
  const subs = [];
  const emit = (e, id, a) => subs.forEach(f => { try { f(e, id, a); } catch (x) { console.error(x); } });
  const T = { native: !!plug, kind: plug ? 'lan' : 'loopback', PORT: PORT, on: f => subs.push(f) };

  if (plug) {
    plug.addListener('net', o => emit(o.e, o.id, o.a));
    T.info = () => plug.getNetInfo();
    T.startServer = name => plug.startServer({ port: PORT, discPort: DISC, name: name });
    T.stopServer = () => plug.stopServer();
    T.connect = (host, port) => plug.connect({ host: host, port: port || PORT, timeoutMs: 5000 });
    T.disconnect = () => plug.disconnect();
    T.send = (id, line, lossy) => { plug.send({ id: id, line: line, lossy: !!lossy }); };
    T.discover = () => plug.discover({ timeoutMs: 2500 });
    T.kick = id => plug.kick({ id: id });
  } else {
    // ---- тестовый транспорт между вкладками ----
    let ch = null; try { ch = new BroadcastChannel('lc-lan-test'); } catch (e) { }
    const me = Math.random().toString(36).slice(2);
    let hostOn = false, name = '', cons = {}, nextId = 1, cli = null, pend = null;
    const post = m => { if (ch) { m.from = me; ch.postMessage(m); } };
    if (ch) ch.onmessage = ev => {
      const m = ev.data; if (!m || m.from === me) return;
      if (hostOn) {
        if (m.t === 'probe') post({ t: 'room', to: m.from, name: name, port: PORT, players: 1 + Object.keys(cons).length });
        else if (m.t === 'join') { const id = nextId++; cons[id] = m.from; post({ t: 'ok', to: m.from, id: id }); emit('client+', id, 'local'); }
        else if (m.t === 'm' && m.to === 'host') { const id = Object.keys(cons).find(k => cons[k] === m.from); if (id) emit('msg', +id, m.line); }
        else if (m.t === 'leave') { const id = Object.keys(cons).find(k => cons[k] === m.from); if (id) { delete cons[id]; emit('client-', +id, 'left'); } }
      }
      if (m.to !== me) return;
      if (m.t === 'ok' && pend) { cli = m.from; const p = pend; pend = null; p.res(); }
      else if (m.t === 'm' && cli) emit('msg', 0, m.line);
      else if (m.t === 'closed' && cli) { cli = null; emit('closed', 0, 'host-closed'); }
      else if (m.t === 'room' && T._found) T._found.push({ ip: 'эта вкладка/устройство', port: m.port, name: m.name, players: m.players });
    };
    T.info = () => Promise.resolve({ ips: [{ name: 'test', ip: '127.0.0.1', prefix: 8 }], wifi: true, gateway: '', targets: [] });
    T.startServer = n => { name = n; if (hostOn) return Promise.resolve({ port: PORT, already: true, ips: [] }); hostOn = true; return Promise.resolve({ port: PORT, already: false, ips: [] }); };
    T.stopServer = () => { if (hostOn) { Object.keys(cons).forEach(k => post({ t: 'closed', to: cons[k] })); } hostOn = false; cons = {}; return Promise.resolve(); };
    T.connect = () => new Promise((res, rej) => {
      if (cli) { post({ t: 'leave', to: cli }); cli = null; }
      pend = { res: res }; post({ t: 'join' });
      setTimeout(() => { if (pend) { pend = null; const e = new Error('ECONNREFUSED'); e.code = 'ECONNREFUSED'; rej(e); } }, 1500);
    });
    T.disconnect = () => { if (cli) post({ t: 'leave', to: cli }); cli = null; return Promise.resolve(); };
    T.send = (id, line) => {
      if (hostOn) { if (id >= 0) { if (cons[id]) post({ t: 'm', to: cons[id], line: line }); } else Object.keys(cons).forEach(k => post({ t: 'm', to: cons[k], line: line })); }
      else if (cli) post({ t: 'm', to: 'host', line: line, host: cli });
    };
    // сообщения гостя адресуются хосту по id вкладки
    const origPost = post;
    T.discover = () => new Promise(res => { T._found = []; origPost({ t: 'probe' }); setTimeout(() => { const r = T._found; T._found = null; res({ rooms: r }); }, 700); });
    T.kick = id => { if (cons[id]) { post({ t: 'closed', to: cons[id] }); delete cons[id]; emit('client-', id, 'kicked'); } };
    // хост принимает 'm' c to==='host' от любой вкладки
    if (ch) { const base = ch.onmessage; ch.onmessage = ev => { const m = ev.data; if (m && m.t === 'm' && m.to === 'host' && m.host && m.host !== me) return; base(ev); }; }
  }
  window.NetT = T;
})();
